Free points & warm-up for everyone.

Just read this blog https://acquykhud.github.io/2021/11/28/ISITDTU-Quals-2021.html and build tools to decompile flag.luac