Write a tool that allow you to teleport to different maps in this game.

Then teleport to the hidden map with scene_id = "scene06".

You could use check_scene_id.luac to check your current map's scene_id

Once you got into the hidden map, go to x=769, y=439 to get the flag.

Download the game at: https://cuuam.gosu.vn/tai-game.html

Make sure you joined game server named "Thai Son"